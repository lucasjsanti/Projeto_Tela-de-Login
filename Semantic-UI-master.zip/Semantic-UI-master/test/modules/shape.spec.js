describe("UI Shape", function() {

  moduleTests({
    module    : 'shape',
    element   : '.ui.shape'
  });

});